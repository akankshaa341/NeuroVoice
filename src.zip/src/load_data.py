
from pathlib import Path
import pandas as pd

# Locate the main NeuroVoice folder
PROJECT_ROOT = Path(__file__).resolve().parents[1]

# Locate the Excel workbook
EXCEL_PATH = (
    PROJECT_ROOT
    / "data"
    / "raw"
    / "IMS_EEG_with_TextLabels1000D.xlsx"
)


def load_dataset():
    # Check whether the workbook exists
    if not EXCEL_PATH.exists():
        raise FileNotFoundError(
            f"Excel file not found at:\n{EXCEL_PATH}"
        )

    # Read the workbook without assuming a header row
    df = pd.read_excel(EXCEL_PATH, header=None)

    print("Excel file loaded successfully!")
    print("Dataset shape:", df.shape)
    print("\nFirst five rows:")
    print(df.head())

    return df


if __name__ == "__main__":
    load_dataset()
