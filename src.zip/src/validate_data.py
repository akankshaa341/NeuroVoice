
from pathlib import Path
import json
import numpy as np

from src.load_data import load_dataset

PROJECT_ROOT = Path(__file__).resolve().parents[1]
OUTPUT_DIR = PROJECT_ROOT / "data" / "processed"

EXPECTED_LABELS = {
    "play", "Happy", "under", "ball", "dog", "cat"
}


def validate_dataset():
    df = load_dataset()

    # Extract EEG signals and labels
    signals = df.iloc[:, :1000].to_numpy(dtype=np.float64)
    labels = df.iloc[:, 1000].astype("string").str.strip()

    # Check the overall dimensions
    assert signals.shape == (5760, 1000), (
        f"Unexpected signal shape: {signals.shape}"
    )

    assert len(labels) == 5760, "Unexpected number of labels."

    # Check for invalid signal values
    assert np.isfinite(signals).all(), (
        "EEG signals contain NaN or infinite values."
    )

    # Check for missing labels
    assert labels.notna().all(), "Missing labels found."
    assert labels.ne("").all(), "Empty labels found."

    # Group eight rows into one trial
    X = signals.reshape(720, 8, 1000)
    label_matrix = labels.to_numpy().reshape(720, 8)

    # Verify that all eight rows have the same trial label
    assert np.all(label_matrix == label_matrix[:, :1]), (
        "Some trials have inconsistent labels."
    )

    y = label_matrix[:, 0]

    # Check the six expected classes
    found_labels = set(np.unique(y))
    assert found_labels == EXPECTED_LABELS, (
        f"Unexpected labels: {found_labels}"
    )

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    # Save the validated dataset
    np.savez_compressed(
        OUTPUT_DIR / "validated_dataset.npz",
        X=X,
        y=y.astype(str)
    )

    # Save a validation report
    counts = {
        str(label): int(np.sum(y == label))
        for label in sorted(found_labels)
    }

    report = {
        "trials": int(len(y)),
        "channels": int(X.shape[1]),
        "samples_per_channel": int(X.shape[2]),
        "classes": counts,
        "finite_signals": True,
        "consistent_trial_labels": True
    }

    with open(
        OUTPUT_DIR / "validation_report.json",
        "w",
        encoding="utf-8"
    ) as file:
        json.dump(report, file, indent=4)

    print("\nVALIDATION SUCCESSFUL")
    print("EEG shape:", X.shape)
    print("Labels shape:", y.shape)
    print("Class counts:", counts)
    print("Saved to:", OUTPUT_DIR)


if __name__ == "__main__":
    validate_dataset()
