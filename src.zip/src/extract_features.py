
from pathlib import Path

import numpy as np
from scipy.signal import welch


ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data" / "processed"

INPUT_FILE = DATA_DIR / "preprocessed_data.npz"
OUTPUT_FILE = DATA_DIR / "eeg_features.npz"

FS = 500

BANDS = [
    (4, 8),
    (8, 13),
    (13, 30),
    (30, 40),
]


def features_for_trial(trial):
    """
    trial shape: (8 channels, 1000 samples)
    Returns 72 features for one trial.
    """
    features = []

    for signal in trial:
        signal = np.asarray(signal, dtype=np.float64)

        # Time-domain features
        std = np.std(signal)
        rms = np.sqrt(np.mean(signal ** 2))
        ptp = np.ptp(signal)

        # Hjorth parameters
        first_diff = np.diff(signal)
        second_diff = np.diff(first_diff)

        activity = np.var(signal)
        mobility = (
            np.sqrt(np.var(first_diff) / activity)
            if activity > 1e-12 else 0.0
        )

        mobility_diff = (
            np.sqrt(np.var(second_diff) / np.var(first_diff))
            if np.var(first_diff) > 1e-12 else 0.0
        )

        complexity = (
            mobility_diff / mobility
            if mobility > 1e-12 else 0.0
        )

        # Frequency-domain features
        freqs, psd = welch(
            signal,
            fs=FS,
            nperseg=min(500, len(signal))
        )

        band_powers = []
        for low, high in BANDS:
            mask = (freqs >= low) & (freqs < high)

            if np.count_nonzero(mask) >= 2:
                power = np.trapezoid(psd[mask], freqs[mask])
            else:
                power = 0.0

            band_powers.append(np.log10(power + 1e-12))

        features.extend([
            std, rms, ptp, mobility, complexity,
            *band_powers
        ])

    return np.asarray(features, dtype=np.float64)


def transform_trials(X):
    return np.vstack([
        features_for_trial(trial) for trial in X
    ])


def main():
    if not INPUT_FILE.exists():
        raise FileNotFoundError(
            f"Missing {INPUT_FILE}. Run preprocessing first."
        )

    with np.load(INPUT_FILE, allow_pickle=False) as data:
        X_train = data["X_train"]
        X_val = data["X_val"]
        X_test = data["X_test"]

        y_train = data["y_train"]
        y_val = data["y_val"]
        y_test = data["y_test"]

        train_indices = data["train_indices"]
        val_indices = data["val_indices"]
        test_indices = data["test_indices"]

    print("Extracting training features...")
    F_train = transform_trials(X_train)

    print("Extracting validation features...")
    F_val = transform_trials(X_val)

    print("Extracting test features...")
    F_test = transform_trials(X_test)

    if not all(np.isfinite(F).all()
               for F in [F_train, F_val, F_test]):
        raise ValueError("Non-finite feature values detected.")

    DATA_DIR.mkdir(parents=True, exist_ok=True)

    np.savez_compressed(
        OUTPUT_FILE,
        F_train=F_train,
        y_train=y_train,
        F_val=F_val,
        y_val=y_val,
        F_test=F_test,
        y_test=y_test,
        train_indices=train_indices,
        val_indices=val_indices,
        test_indices=test_indices
    )

    print("\nFeature extraction complete.")
    print("Training:", F_train.shape)
    print("Validation:", F_val.shape)
    print("Testing:", F_test.shape)
    print("Saved:", OUTPUT_FILE)


if __name__ == "__main__":
    main()
