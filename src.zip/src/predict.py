
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

ROOT = Path(__file__).resolve().parents[1]

FEATURES_FILE = ROOT / "data" / "processed" / "eeg_features.npz"
MODEL_FILE = ROOT / "models" / "svm_baseline.joblib"
REPORTS_DIR = ROOT / "reports"

LABELS = ["play", "Happy", "under", "ball", "dog", "cat"]


def main():
    # Load all 108 test trials
    with np.load(FEATURES_FILE, allow_pickle=False) as data:
        X_test = data["F_test"]
        y_true = data["y_test"]

    print("Test feature shape:", X_test.shape)
    print("Test label shape:", y_true.shape)

    # Load the existing trained SVM
    model = joblib.load(MODEL_FILE)

    # Predict all test trials, not just the first one
    y_pred = model.predict(X_test)

    print("\n===== PREDICTIONS FOR ALL TEST TRIALS =====")
    results = pd.DataFrame({
        "Trial": np.arange(1, len(y_true) + 1),
        "True_Label": y_true,
        "Predicted_Label": y_pred,
        "Correct": np.asarray(y_true) == np.asarray(y_pred),
    })
    print(results.to_string(index=False))

    print("\n===== COUNTS FOR ALL SIX LABELS =====")
    counts = pd.Series(y_pred).value_counts().reindex(LABELS, fill_value=0)
    print(counts.to_string())
    print("Total predictions:", len(y_pred))

    print("\n===== TEST ACCURACY =====")
    print(f"{accuracy_score(y_true, y_pred) * 100:.2f}%")

    print("\n===== CLASSIFICATION REPORT =====")
    print(classification_report(
        y_true, y_pred, labels=LABELS, zero_division=0
    ))

    print("\n===== CONFUSION MATRIX =====")
    print(pd.DataFrame(
        confusion_matrix(y_true, y_pred, labels=LABELS),
        index=[f"True_{x}" for x in LABELS],
        columns=[f"Pred_{x}" for x in LABELS],
    ))

    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    results.to_csv(REPORTS_DIR / "all_test_predictions.csv", index=False)
    counts.rename_axis("Label").to_csv(
        REPORTS_DIR / "prediction_counts.csv"
    )

    print("\nSaved results to:", REPORTS_DIR)


if __name__ == "__main__":
    main()
