
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_FILE = (
    PROJECT_ROOT / "data" / "processed" / "validated_dataset.npz"
)
REPORT_DIR = PROJECT_ROOT / "reports"

FS = 500  # Sampling frequency in Hz


def inspect_eeg():
    if not DATA_FILE.exists():
        raise FileNotFoundError(
            "Run the validation program before inspecting EEG."
        )

    with np.load(DATA_FILE, allow_pickle=False) as data:
        X = data["X"]
        y = data["y"]

    REPORT_DIR.mkdir(parents=True, exist_ok=True)

    # Inspect the first trial
    trial_number = 0
    trial = X[trial_number]
    time = np.arange(trial.shape[1]) / FS

    fig, axes = plt.subplots(
        trial.shape[0], 1, figsize=(12, 12), sharex=True
    )

    for channel in range(trial.shape[0]):
        axes[channel].plot(time, trial[channel])
        axes[channel].set_ylabel(f"Ch {channel + 1}")
        axes[channel].grid(True, alpha=0.3)

    axes[-1].set_xlabel("Time (seconds)")
    fig.suptitle(f"Trial 1 — Label: {y[trial_number]}")
    fig.tight_layout()

    output_path = REPORT_DIR / "raw_eeg_trial_1.png"
    fig.savefig(output_path, dpi=150)
    plt.show()

    # Print basic signal statistics
    print("EEG data shape:", X.shape)
    print("Minimum value:", np.min(X))
    print("Maximum value:", np.max(X))
    print("Mean value:", np.mean(X))
    print("Standard deviation:", np.std(X))
    print("Saved plot to:", output_path)


if __name__ == "__main__":
    inspect_eeg()
