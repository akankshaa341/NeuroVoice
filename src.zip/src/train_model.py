
from pathlib import Path
import json

import joblib
import numpy as np
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    f1_score,
    classification_report,
)


ROOT = Path(__file__).resolve().parents[1]
DATA_FILE = ROOT / "data" / "processed" / "eeg_features.npz"
MODEL_DIR = ROOT / "models"
REPORT_DIR = ROOT / "reports"


def main():
    if not DATA_FILE.exists():
        raise FileNotFoundError(
            "Features not found. Run src.extract_features first."
        )

    with np.load(DATA_FILE, allow_pickle=False) as data:
        X_train = data["F_train"]
        y_train = data["y_train"]
        X_val = data["F_val"]
        y_val = data["y_val"]

    model = Pipeline([
        ("scaler", StandardScaler()),
        ("svm", SVC(
            kernel="rbf",
            C=1.0,
            gamma="scale",
            class_weight="balanced"
        ))
    ])

    print("Training SVM...")
    model.fit(X_train, y_train)

    predictions = model.predict(X_val)

    metrics = {
        "accuracy": float(
            accuracy_score(y_val, predictions)
        ),
        "balanced_accuracy": float(
            balanced_accuracy_score(y_val, predictions)
        ),
        "macro_f1": float(
            f1_score(y_val, predictions, average="macro")
        ),
        "validation_classification_report": classification_report(
            y_val,
            predictions,
            output_dict=True,
            zero_division=0
        )
    }

    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    REPORT_DIR.mkdir(parents=True, exist_ok=True)

    joblib.dump(model, MODEL_DIR / "svm_baseline.joblib")

    with open(
        REPORT_DIR / "svm_validation_metrics.json",
        "w",
        encoding="utf-8"
    ) as f:
        json.dump(metrics, f, indent=4)

    print("\nValidation results")
    print(f"Accuracy:          {metrics['accuracy']:.3f}")
    print(f"Balanced accuracy: {metrics['balanced_accuracy']:.3f}")
    print(f"Macro F1:          {metrics['macro_f1']:.3f}")
    print("\n", classification_report(
        y_val, predictions, zero_division=0
    ))

    print("Saved model:", MODEL_DIR / "svm_baseline.joblib")


if __name__ == "__main__":
    main()
