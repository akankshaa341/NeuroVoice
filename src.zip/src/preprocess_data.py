
from pathlib import Path
import json

import numpy as np
from scipy.signal import butter, sosfiltfilt


# --------------------------------------------------
# 1. Paths and settings
# --------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PROJECT_ROOT / "data" / "processed"
REPORT_DIR = PROJECT_ROOT / "reports"

INPUT_FILE = DATA_DIR / "data_splits.npz"
OUTPUT_FILE = DATA_DIR / "preprocessed_data.npz"
REPORT_FILE = REPORT_DIR / "preprocessing_report.json"

FS = 500
LOW_CUTOFF = 1.0
HIGH_CUTOFF = 40.0
FILTER_ORDER = 4

# Initial screening rule, not a universal clinical threshold
ARTIFACT_MAD_MULTIPLIER = 6.0


# --------------------------------------------------
# 2. Filtering
# --------------------------------------------------

def filter_eeg(X):
    """
    X shape: (trials, channels, samples).

    Uses zero-phase filtering for offline analysis.
    This is not a causal filter for live streaming.
    """
    if X.ndim != 3:
        raise ValueError(f"Expected 3D EEG data, got {X.shape}")

    if not 0 < LOW_CUTOFF < HIGH_CUTOFF < FS / 2:
        raise ValueError("Invalid filter cutoffs or sampling frequency.")

    sos = butter(
        FILTER_ORDER,
        [LOW_CUTOFF, HIGH_CUTOFF],
        btype="bandpass",
        fs=FS,
        output="sos"
    )

    filtered = sosfiltfilt(sos, X, axis=-1)

    if not np.isfinite(filtered).all():
        raise ValueError("Filtering produced non-finite values.")

    return filtered


# --------------------------------------------------
# 3. Artifact screening
# --------------------------------------------------

def detect_artifacts(X_train, X_val, X_test):
    """
    Flags suspicious trial/channel combinations.

    Thresholds are learned from training trials only.
    Flags are for inspection; trials are not deleted.
    """
    # Peak-to-peak amplitude for every trial and channel
    train_ptp = np.ptp(X_train, axis=-1)

    # Robust channel-wise threshold from training trials
    median = np.median(train_ptp, axis=0)
    mad = np.median(
        np.abs(train_ptp - median[None, :]),
        axis=0
    )

    robust_scale = 1.4826 * mad

    # Fallback when MAD is zero
    percentile_fallback = np.percentile(train_ptp, 99.5, axis=0)
    threshold = np.where(
        robust_scale > 0,
        median + ARTIFACT_MAD_MULTIPLIER * robust_scale,
        percentile_fallback
    )

    # Extremely small values indicate a flat channel.
    # Exact zero is used to avoid assuming EEG amplitude units.
    def flag_trials(X):
        ptp = np.ptp(X, axis=-1)
        flat = np.std(X, axis=-1) == 0
        extreme = ptp > threshold[None, :]
        return flat | extreme

    flags_train = flag_trials(X_train)
    flags_val = flag_trials(X_val)
    flags_test = flag_trials(X_test)

    report = {
        "screening_rule": (
            "Flat channels or channel peak-to-peak amplitude "
            "above a training-derived robust threshold"
        ),
        "mad_multiplier": ARTIFACT_MAD_MULTIPLIER,
        "channel_thresholds": threshold.tolist(),
        "train_flagged_channels": int(flags_train.sum()),
        "validation_flagged_channels": int(flags_val.sum()),
        "test_flagged_channels": int(flags_test.sum()),
        "train_flagged_trials": int(flags_train.any(axis=1).sum()),
        "validation_flagged_trials": int(flags_val.any(axis=1).sum()),
        "test_flagged_trials": int(flags_test.any(axis=1).sum()),
        "note": (
            "Flags indicate candidates for inspection, not confirmed "
            "artifacts. No trials or channels were removed."
        )
    }

    return flags_train, flags_val, flags_test, report


# --------------------------------------------------
# 4. Normalization
# --------------------------------------------------

def normalize_data(X_train, X_val, X_test):
    """
    Standardize each channel using training-set statistics only.

    Statistics are calculated over training trials and time samples.
    """
    mean = X_train.mean(axis=(0, 2), keepdims=True)
    std = X_train.std(axis=(0, 2), keepdims=True)

    # Prevent division by zero for constant channels
    safe_std = np.where(std > 0, std, 1.0)

    X_train_norm = (X_train - mean) / safe_std
    X_val_norm = (X_val - mean) / safe_std
    X_test_norm = (X_test - mean) / safe_std

    return (
        X_train_norm,
        X_val_norm,
        X_test_norm,
        mean.reshape(-1),
        safe_std.reshape(-1)
    )


# --------------------------------------------------
# 5. Main pipeline
# --------------------------------------------------

def preprocess_dataset():
    if not INPUT_FILE.exists():
        raise FileNotFoundError(
            f"Split file not found: {INPUT_FILE}\n"
            "Run the data-splitting program first."
        )

    with np.load(INPUT_FILE, allow_pickle=False) as data:
        X_train = data["X_train"].astype(np.float64)
        X_val = data["X_val"].astype(np.float64)
        X_test = data["X_test"].astype(np.float64)

        y_train = data["y_train"]
        y_val = data["y_val"]
        y_test = data["y_test"]

        # Preserve trial indices if available
        train_idx = data["train_indices"]
        val_idx = data["val_indices"]
        test_idx = data["test_indices"]

    for name, X in [
        ("training", X_train),
        ("validation", X_val),
        ("testing", X_test)
    ]:
        if X.ndim != 3 or X.shape[1:] != (8, 1000):
            raise ValueError(
                f"Unexpected {name} shape: {X.shape}"
            )
        if not np.isfinite(X).all():
            raise ValueError(f"{name} data contains invalid values.")

    print("Filtering EEG signals...")
    X_train_f = filter_eeg(X_train)
    X_val_f = filter_eeg(X_val)
    X_test_f = filter_eeg(X_test)

    print("Screening for potential artifacts...")
    flags_train, flags_val, flags_test, artifact_report = (
        detect_artifacts(X_train_f, X_val_f, X_test_f)
    )

    print("Normalizing using training statistics only...")
    (
        X_train_n,
        X_val_n,
        X_test_n,
        channel_means,
        channel_stds
    ) = normalize_data(X_train_f, X_val_f, X_test_f)

    DATA_DIR.mkdir(parents=True, exist_ok=True)
    REPORT_DIR.mkdir(parents=True, exist_ok=True)

    np.savez_compressed(
        OUTPUT_FILE,
        X_train=X_train_n,
        y_train=y_train,
        X_val=X_val_n,
        y_val=y_val,
        X_test=X_test_n,
        y_test=y_test,
        train_indices=train_idx,
        val_indices=val_idx,
        test_indices=test_idx,
        artifact_flags_train=flags_train,
        artifact_flags_val=flags_val,
        artifact_flags_test=flags_test,
        channel_means=channel_means,
        channel_stds=channel_stds
    )

    report = {
        "sampling_frequency_hz": FS,
        "filter": "Butterworth bandpass",
        "filter_order": FILTER_ORDER,
        "low_cutoff_hz": LOW_CUTOFF,
        "high_cutoff_hz": HIGH_CUTOFF,
        "normalization": (
            "Per-channel z-score using training trials and time samples"
        ),
        "train_shape": list(X_train_n.shape),
        "validation_shape": list(X_val_n.shape),
        "test_shape": list(X_test_n.shape),
        "artifact_screening": artifact_report
    }

    with open(REPORT_FILE, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=4)

    print("\nPreprocessing completed.")
    print("Training shape:", X_train_n.shape)
    print("Validation shape:", X_val_n.shape)
    print("Testing shape:", X_test_n.shape)
    print("Potential artifact flags:", artifact_report)
    print("Saved data:", OUTPUT_FILE)
    print("Saved report:", REPORT_FILE)


if __name__ == "__main__":
    preprocess_dataset()
