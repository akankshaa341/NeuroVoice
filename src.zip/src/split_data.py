
from pathlib import Path

import numpy as np
from sklearn.model_selection import train_test_split


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PROJECT_ROOT / "data" / "processed"

INPUT_FILE = DATA_DIR / "validated_dataset.npz"
OUTPUT_FILE = DATA_DIR / "data_splits.npz"

RANDOM_SEED = 42


def split_dataset():
    if not INPUT_FILE.exists():
        raise FileNotFoundError(
            f"Validated dataset not found: {INPUT_FILE}\n"
            "Run the validation program first."
        )

    # Load validated EEG data and labels
    with np.load(INPUT_FILE, allow_pickle=False) as data:
        X = data["X"]
        y = data["y"]

    print("Original EEG shape:", X.shape)
    print("Original label shape:", y.shape)

    # Create trial indices
    indices = np.arange(len(y))

    # Reserve 15% for final testing
    train_val_idx, test_idx = train_test_split(
        indices,
        test_size=0.15,
        random_state=RANDOM_SEED,
        stratify=y
    )

    # Split the remaining data into training and validation
    train_idx, val_idx = train_test_split(
        train_val_idx,
        test_size=0.15 / 0.85,
        random_state=RANDOM_SEED,
        stratify=y[train_val_idx]
    )

    # Select complete trials
    X_train, y_train = X[train_idx], y[train_idx]
    X_val, y_val = X[val_idx], y[val_idx]
    X_test, y_test = X[test_idx], y[test_idx]

    # Confirm that no trial appears in multiple sets
    assert len(set(train_idx) & set(val_idx)) == 0
    assert len(set(train_idx) & set(test_idx)) == 0
    assert len(set(val_idx) & set(test_idx)) == 0

    # Save data and original trial indices
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    np.savez_compressed(
        OUTPUT_FILE,
        X_train=X_train,
        y_train=y_train,
        X_val=X_val,
        y_val=y_val,
        X_test=X_test,
        y_test=y_test,
        train_indices=train_idx,
        val_indices=val_idx,
        test_indices=test_idx
    )

    print("\nSplit successful!")
    print("Training trials:", len(train_idx))
    print("Validation trials:", len(val_idx))
    print("Testing trials:", len(test_idx))

    print("\nEEG shapes:")
    print("Training:", X_train.shape)
    print("Validation:", X_val.shape)
    print("Testing:", X_test.shape)

    print("\nSaved to:", OUTPUT_FILE)


if __name__ == "__main__":
    split_dataset()
