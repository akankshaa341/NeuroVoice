
from pathlib import Path
import json

import joblib
import numpy as np
import matplotlib.pyplot as plt

from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    f1_score,
    classification_report,
    confusion_matrix,
    ConfusionMatrixDisplay,
)


ROOT = Path(__file__).resolve().parents[1]
DATA_FILE = ROOT / "data" / "processed" / "eeg_features.npz"
MODEL_FILE = ROOT / "models" / "svm_baseline.joblib"
REPORT_DIR = ROOT / "reports"


def main():
    if not DATA_FILE.exists() or not MODEL_FILE.exists():
        raise FileNotFoundError(
            "Run feature extraction and model training first."
        )

    with np.load(DATA_FILE, allow_pickle=False) as data:
        X_test = data["F_test"]
        y_test = data["y_test"]

    model = joblib.load(MODEL_FILE)
    predictions = model.predict(X_test)

    labels = sorted(np.unique(
        np.concatenate([y_test, predictions])
    ).tolist())

    results = {
        "test_trials": int(len(y_test)),
        "accuracy": float(
            accuracy_score(y_test, predictions)
        ),
        "balanced_accuracy": float(
            balanced_accuracy_score(y_test, predictions)
        ),
        "macro_f1": float(
            f1_score(y_test, predictions, average="macro")
        ),
        "classification_report": classification_report(
            y_test,
            predictions,
            labels=labels,
            output_dict=True,
            zero_division=0
        )
    }

    REPORT_DIR.mkdir(parents=True, exist_ok=True)

    with open(
        REPORT_DIR / "svm_test_metrics.json",
        "w",
        encoding="utf-8"
    ) as f:
        json.dump(results, f, indent=4)

    cm = confusion_matrix(y_test, predictions, labels=labels)

    display = ConfusionMatrixDisplay(
        confusion_matrix=cm,
        display_labels=labels
    )

    fig, ax = plt.subplots(figsize=(8, 7))
    display.plot(ax=ax, cmap="Blues", values_format="d")
    ax.set_title("NeuroVoice — SVM Test Confusion Matrix")
    fig.tight_layout()

    plot_path = REPORT_DIR / "svm_confusion_matrix.png"
    fig.savefig(plot_path, dpi=150)
    plt.show()

    print("\nFinal test results")
    print(f"Accuracy:          {results['accuracy']:.3f}")
    print(f"Balanced accuracy: {results['balanced_accuracy']:.3f}")
    print(f"Macro F1:          {results['macro_f1']:.3f}")
    print("\n", classification_report(
        y_test, predictions, labels=labels, zero_division=0
    ))
    print("Metrics saved to:", REPORT_DIR / "svm_test_metrics.json")
    print("Confusion matrix saved to:", plot_path)


if __name__ == "__main__":
    main()
